# Paradox
paradox/ ˈparədɒks/  seemingly absurd contradictory statement  which when investigated may prove to be well founded or true."the uncertainty principle leads to all sorts of mistories, like in terms,self-contradiction , being in two places at once.Conflicts More KULTURE.
